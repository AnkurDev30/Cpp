//AppMain.cpp
#include"AppMain.h"

int main()
{
    accountDetailsN::accountDetailsC obj;
    obj.setData();
}