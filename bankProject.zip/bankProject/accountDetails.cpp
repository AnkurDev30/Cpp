//accountDetails.cpp
#include"acountDetails.h"

void cinIgnore()
{
    cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}
void clearScreen()
{
#ifdef _WIN32
    system("cls");     // Windows
#else
    system("clear");   // Linux/Ubuntu
#endif
}
unsigned int accountDetailsN::accountDetailsN:: getAccountNumber()
{
    return accountNumber;
}
unsigned int accountDetailsN::accountDetailsN::getAccountBalance()
{
    return accountBalance;
}
unsigned int accountDetailsN::accountDetailsN::getAccountPinCity()
{
    return accountPinCity;
}
long long accountDetailsN::accountDetailsN::getAccountMobileNum()
{
    return accountMobileNum;
}
std::string accountDetailsN::accountDetailsN::getAccountName()
{
    return accountName;
}
std::string accountDetailsN::accountDetailsN::getAccountAddress()       
{
    return accountAddress;
} 
bool accountDetailsN::accountDetailsN::nameCheck(std::string name)
{
    bool nameOk=false;
    for(int i=0;i<name.length();i++)
    {
        if((name[i]>'a' && name[i]<'z')||
        (name[i]>'A' && name[i]<'Z')||(name[i]==' '))
        {
            nameOk=true;
        }
        else
        {
            nameOk=false;
            break;
        }
    }
    return nameOk;
}
bool accountDetailsN::accountDetailsN::checkAccountNumber(unsigned int readGenratedAccNum)
{
    bool flag=false;
    int readAcctemp=0;
    std::ifstream file2("AccountNumSave.txt",std::ios::in);

    while(file2>>readAcctemp)
    {
        if(readAcctemp == readGenratedAccNum)
        {
            std::cout<<"account number available \n";
            flag=true;
            break;
        }
    }
    return flag;
}
int accountDetailsN::accountDetailsN::generateAccountNumber()
{
    unsigned int randomAccNum; 
    bool checkAcc;
    char charExp;
    do
    {
        std::cout<<"account number generating....\n";
        srand(time(0)); 

        std::ofstream file1("AccountNumSave.txt",std::ios::app);
        if(file1.is_open()==true)
        {
            randomAccNum = rand() % 9000 + 1000;
            
            checkAcc = checkAccountNumber(randomAccNum);

            if(checkAcc==false)
            {
                std::cout<<"need to genrate new account number\n";
                std::cout<<randomAccNum<<" is already available\n";
                std::cout<<"press y for new account number\n";
                std::cin>>charExp;

            }
            else
            {
                std::cout<<"generated account number : "<<randomAccNum<<std::endl;
                file1<<randomAccNum<<std::endl;
            }
            
        }
        file.close();
    }while(checkAcc==false);
}

void accountDetailsN::accountDetailsN::setData()
{
    bool nameCheckBool=false;
    bool accountNumCheck=false;
    int accNumber=0;

    //name 
    do
    {
        std::cout<<"enter account holder name\n";
        getline(std::cin,accountName);
        nameCheckBool = nameCheck(accountName);

        if(nameCheckBool == false)
        {
            std::cout<<"name should be upercase, lowercase or space only\n";
        }

    }while(nameCheckBool==false);

    //address
    std::cout<<"enter address\n";
    getline(std::cin,accountAddress);

    //pin code
    do
    {
        std::cout<<"enter pin code\n";
        std::cin>>accountPinCity;
        cinIgnore();
        if(accountPinCity<100000)
        {
            std::cout<<"pin shoild be 6 digit \n";
        }
    }while(accountBalance<100000);

    //mobile
    do
    {
        std::cout<<"enter mobile number\n";
        std::cin>>accountMobileNum;
        cinIgnore();
        if(accountMobileNum<=999999999)
        {
            std::cout<<"mobile numbner shoild be 10 digit \n";
        }
    }while(accountMobileNum<=999999999);

    //generate Account number.
    accNumber = generateAccountNumber();
 
    //enter balance
    do
    {
        std::cout<<"enter account opening balance\n";
        std::cin>>accountBalance;
        cinIgnore();
        if(accountBalance<1000)
        {
            std::cout<<"please use minimum ammount 1000/- Rs\n";
        }
    }while(accountBalance<1000);

}