//AppMain.h
#ifdef AppMain_h
#define AppMain_h

#include"accountDetails.h"

#endif